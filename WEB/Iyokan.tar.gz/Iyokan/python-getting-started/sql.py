import json, random
from flask import Flask, request
from db import Db

app = Flask(__name__)
app.debug = True

# DATABASE_URL=postgres://<username>@localhost/<dbname> python main.py

def json_response(data="OK", status=200):
  return json.dumps(data), status, { "Content-Type": "application/json" }

@app.route("/phrases/random", methods=["GET"])
def random_phrase():
  db = Db()
  name = db.select("SELECT * FROM names ORDER BY random() LIMIT 1")[0]["value"]
  verb = db.select("SELECT * FROM verbs ORDER BY random() LIMIT 1")[0]["value"]
  adjective = db.select("SELECT * FROM adjectives ORDER BY random() LIMIT 1")[0]["value"]
  db.close()
  return " ".join([name.title(), verb, adjective]) + random.choice([".", " !", " ?"])

@app.route("/phrases/elements", methods=["POST"])
def add_elements():
  elements = request.get_json()

  if "name" not in elements or len(elements["name"]) == 0:
    return json_response({ "error" : "Missing name" }, 400)
  if "verb" not in elements or len(elements["verb"]) == 0:
    return json_response({ "error" : "Missing verb" }, 400)
  if "adjective" not in elements or len(elements["adjective"]) == 0:
    return json_response({ "error" : "Missing adjective" }, 400)

  db = Db()
  db.execute("""
    INSERT INTO names VALUES (@(name));
    INSERT INTO verbs VALUES (@(verb));
    INSERT INTO adjectives VALUES (@(adjective));
  """, elements)
  db.close()

  return json_response()

if __name__ == "__main__":
  app.run()

