#!/usr/bin/env python2.7
# coding: utf-8

from flask import Flask, request
from flask_cors import CORS
import json
import random
import psycopg2
from db import Db

app = Flask(__name__)
app.debug = True
CORS(app)

################################################################################
##### Quelques constantes

COST_PER_GLASS  = 0.15 # le cout de production
PRICE_PER_GLASS = 0.35 # le prix de vente
HOUR_OF_DAY = 0

# les conditions meteo
WEATHER_VALUES = ["SUNNY AND HOT", "SUNNY", "CLOUDY", "RAINY"]

# la probabilite maximale (entre 0 et 1) de vente pour chaque condition meteo.
SALES_MAX = {
  "SUNNY AND HOT" : 1.0, 
  "SUNNY"         : 0.8,
  "CLOUDY"        : 0.5,
  "RAINY"         : 0.1
}

# la probabilite minimale (entre 0 et 1) de vente pour chaque condition meteo.
SALES_MIN = {
  "SUNNY AND HOT" : 0.6, 
  "SUNNY"         : 0.2,
  "CLOUDY"        : 0.0,
  "RAINY"         : 0.0
}

################################################################################
##### Global variables

day = 1                                           # compteur de jour

budget = 1.0                                      # compteur de jour
current_weather = random.choice(WEATHER_VALUES)   # meteo du jour

################################################################################
##### Logique de jeu

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Incremente le compteur de nombre de jours et selectionne aleatoirement une
# configuration meteo.
def moveToNextDay():  
  global day
  day += 1
  
  global current_weather
  current_weather = random.choice(WEATHER_VALUES)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# En fonction de la mete un nombre de ventes est choisi aleatoirement et le
# budget est mis a jour.
def simulateSales(requested_glasses):
	global budget
	proba = random.uniform(SALES_MIN[current_weather], SALES_MAX[current_weather])
	sales = int(requested_glasses * proba)

	expenses = requested_glasses * COST_PER_GLASS
	earnings = sales * PRICE_PER_GLASS
  
	budget += earnings - expenses
  
	return sales

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@app.route('/')
def homePage():
	return "Bonjour je suis une page de garde. Rajouter /dayinfo ou /heure ou /players ou /player/nom/budget pour un maximum de fun"

@app.route('/test', methods=['POST'])
def testJSON():
	retour = {"player":"","item":"","quantity":""}
	retour = request.get_json()
	return json.dumps(retour),201, {'Content-Type': 'application/json'}

#-------------------------PLAYERS INFOS-------------------------
@app.route('/players')
def getPlayers():
	db = Db()
	nbPlayers = db.select("SELECT COUNT(*) FROM player")[0]["count"]

	player={"name":"", "budget":""}
	players = []
	for i in range(0, nbPlayers):
		players.append({"name": db.select("SELECT * FROM player")[i]["player_name"], "budget": db.select("SELECT * FROM player")[i]["player_budget"]})

	db.close()

	return json.dumps(players), 200, {'Content-Type': 'application/json'}

@app.route('/players/add/<string:name>+<string:budget>')
def createPlayer(name, budget):
	db = Db()
	insertCommand = "INSERT INTO player (player_name, player_budget, player_state) VALUES('" + name +"',"+ budget +",true);"
	db.execute(insertCommand)
	
	db.close()
	return "Insertion done"

@app.route('/players/delete/<string:name>')
def deletePLayer(name):
	db = Db()
	insertCommand = "DELETE FROM player WHERE player_name = '"+ name +"';"
	db.execute(insertCommand)
	
	db.close()
	return "Deletion Done"

#-------------------------ARDUINO(weather/hour) INFOS-------------------------
@app.route('/weather')
def weather(weather):
	return json.dumps(current_weather), 200, {'Content-Type': 'application/json'}

@app.route('/update/weather/<int:weather>')
def updateWeather(weather):
	current_weather = WEATHER_VALUES[weather]
	return json.dumps(current_weather), 200, {'Content-Type': 'application/json'}

@app.route('/hour')
def hour():
	return json.dumps(HOUR_OF_DAY), 200, {'Content-Type': 'application/json'}

@app.route('/update/hour/<int:hour>')
def updateHour(hour):
	HOUR_OF_DAY = hour
	return json.dumps(HOUR_OF_DAY), 200, {'Content-Type': 'application/json'}

#-------------------------PARTIEL INFOS-------------------------
@app.route('/dayinfo')
def getDayInfo():
	informations={"day":"", "budget":"", "weather":""}
	informations['day']=day
	informations['budget']=budget
	informations['weather']=current_weather
	return json.dumps(informations), 200, {'Content-Type': 'application/json'}

@app.route('/order', methods=['POST'])
def postOrder():
	# game over
	if budget < COST_PER_GLASS:
	    # http status 412 = "Precondition Failed"
	    return '"Insufficient funds."', 412, {'Content-Type': 'application/json'}
  
	if not budget < 0:
		requestedGlasses = request.get_json()
		sales = simulateSales(requestedGlasses)

	moveToNextDay()
	
	return json.dumps(sales),201, {'Content-Type': 'application/json'}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  app.run()
