$(document).ready(function(){
	$('#Connection').on('submit', refresh);
});

function refresh(){
		window.location.href = "https://tranquil-reef-75630.herokuapp.com/static/home.html";
}
