$(document).ready(function(){
	setup();
	drinks();
	document.getElementsByName("quantity1Input")[0].addEventListener('change', drinks);
	document.getElementsByName("quantity2Input")[0].addEventListener('change', drinks);
	document.getElementsByName("quantity3Input")[0].addEventListener('change', drinks);
	document.getElementsByName("adSize")[0].addEventListener('change', adPrice);
});

function setup(){
	document.getElementById("quantity1Input").value = 0;
	document.getElementById("quantity2Input").value = 0;
	document.getElementById("quantity3Input").value = 0;
}

function drinks(){
	var nbDrinks = Number(document.getElementById("quantity1Input").value) + Number(document.getElementById("quantity2Input").value) + Number(document.getElementById("quantity3Input").value)
	document.getElementById("drinks").innerHTML = nbDrinks;
}

function adPrice(){
	var nbDrinks = Number(document.getElementById("adSize").value) * 4;
//	document.getElementById("adSize").innerHTML = nbDrinks;
}
