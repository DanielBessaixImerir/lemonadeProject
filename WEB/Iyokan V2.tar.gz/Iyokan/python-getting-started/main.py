#!/usr/bin/env python2.7
# coding: utf-8

from flask import Flask, request
from flask_cors import CORS
import json
import random
import psycopg2
from db import Db

app = Flask(__name__)
app.debug = True
CORS(app)

################################################################################
##### Quelques constantes

COST_PER_GLASS  = 0.15 # le cout de production
PRICE_PER_GLASS = 0.35 # le prix de vente
HOUR_OF_DAY = 0
WEATHER_OF_DAY = ""
FORECAST_OF_DAY = "None"

# les conditions meteo
WEATHER_VALUES = ["SUNNY AND HOT", "SUNNY", "CLOUDY", "RAINY"]

# la probabilite maximale (entre 0 et 1) de vente pour chaque condition meteo.
SALES_MAX = {
  "SUNNY AND HOT" : 1.0, 
  "SUNNY"         : 0.8,
  "CLOUDY"        : 0.5,
  "RAINY"         : 0.1
}

# la probabilite minimale (entre 0 et 1) de vente pour chaque condition meteo.
SALES_MIN = {
  "SUNNY AND HOT" : 0.6, 
  "SUNNY"         : 0.2,
  "CLOUDY"        : 0.0,
  "RAINY"         : 0.0
}

################################################################################
##### Global variables

day = 1                                           # compteur de jour
chat = []
budget = 1.0                                      # compteur de jour
current_weather = random.choice(WEATHER_VALUES)   # meteo du jour

################################################################################
##### Logique de jeu

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Incremente le compteur de nombre de jours et selectionne aleatoirement une
# configuration meteo.
def moveToNextDay():  
  global day
  day += 1
  
  global current_weather
  current_weather = random.choice(WEATHER_VALUES)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# En fonction de la mete un nombre de ventes est choisi aleatoirement et le
# budget est mis a jour.
def simulateSales(requested_glasses):
	global budget
	proba = random.uniform(SALES_MIN[current_weather], SALES_MAX[current_weather])
	sales = int(requested_glasses * proba)

	expenses = requested_glasses * COST_PER_GLASS
	earnings = sales * PRICE_PER_GLASS
  
	budget += earnings - expenses
  
	return sales

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@app.route('/')
def homePage():
	return "Bonjour je suis une page de garde."

@app.route('/test', methods=['POST']) #DEVELOPMENT INTER-PLATFORM TEST ROUTE, DO NOT REMOVE.
def testJSON():
	#player = {"player":"","item":"","quantity":""}
	#player = request.get_json()
	db = Db()
	jsonHOUR = request.get_json()['hour']
	dayHour = db.execute("UPDATE dayHour SET hour_of_day="+ jsonHOUR +" WHERE hour_name='current_hour';")
	db.close()
	return json.dumps(jsonHOUR),201, {'Content-Type': 'application/json'}

#-------------------------PLAYERS INFOS-------------------------
@app.route('/players', methods=['GET'])
def getPlayers():
	db = Db()
	nbPlayers = db.select("SELECT COUNT(*) FROM player")[0]["count"]
	playerList = db.select("SELECT * FROM player ORDER BY player_budget DESC;")
	
	player={"name":"", "budget":""}
	players = []
	for i in range(0, nbPlayers):
		players.append({"name": playerList[i]["player_name"], "budget": playerList[i]["player_budget"]})

	db.close()

	return json.dumps(players), 200, {'Content-Type': 'application/json'}

@app.route('/players', methods=['POST'])
def createPlayer():
	db = Db()
	name = request.get_json()['name']
	player = {"name":"", "location":{"x":"", "y":""}}
	player['location']['y'] = random.randint(0, 550)
	player['location']['x'] = random.randint(0, 470)
	player['name'] = name
	randx = player['location']['y']
	randy = player['location']['x']
	strRandX = str(randx)
	strRandY = str(randy)
	print "THE GENERATED LOCATION : " + strRandX + "," + strRandY
	db.execute("""
				INSERT INTO Player(player_name) VALUES(@(name));
				INSERT INTO Stand(player_id) VALUES((SELECT player_id FROM Player WHERE player_name= @(name)));
				INSERT INTO Coordinates(longitude,latitude,stand_id) VALUES(@(strRandX),@(strRandY),(SELECT stand_id FROM Stand 					WHERE player_id=(SELECT player_id FROM Player WHERE player_name= @(name))));
				UPDATE Player SET stand_id=(SELECT stand_id FROM Stand WHERE player_id=(SELECT player_id FROM Player 
				WHERE player_name= @(name))) WHERE player_id=(SELECT player_id FROM Player WHERE player_name= @(name));""", 
	{
				'name': name, 'strRandX': strRandX, 'strRandY': strRandY
	})
	db.close()

	return json.dumps(player), 200, {'Content-Type': 'application/json'}

#-------------------------ARDUINO(weather/hour) INFOS---------------------------
#GET THE TIME & WEATHER INFORMATIONS
@app.route('/metrology', methods=['GET'])
def getMetrology():
	db = Db()
	currentHour = db.select("SELECT current_hour FROM current_day")[0]['current_hour']
	print currentHour
	currentWeather = db.select("SELECT current_weather FROM current_day")[0]['current_weather']
	currentForecast = db.select("SELECT current_forecast FROM current_day")[0]['current_forecast']
	db.close()
	
	situation = {"timestamp":"", "weather":[{"dfn":"0", "weather":""},{"dfn":"1","weather":""}]}
	situation['timestamp'] = currentHour
	situation['weather'][0]['weather'] = currentWeather
	situation['weather'][1]['weather'] = currentForecast

	return json.dumps(situation), 200, {'Content-Type': 'application/json'}

#POST THE TIME & WEATHER INFORMATIONS
@app.route('/metrology', methods=['POST'])
def postMetrology():
	jsonSituation = request.get_json()
	print "METROLOGY : " + str(jsonSituation)
	insertedHour = ""
	insertedWeather = ""
	insertedForecast = ""
	
	insertedHour = jsonSituation['timestamp']
	strInsertedHour = str(insertedHour)

	if jsonSituation['weather'][0]['dfn'] == 0:
		insertedWeather = jsonSituation['weather'][0]['weather']
		insertedForecast = jsonSituation['weather'][1]['weather']
	if jsonSituation['weather'][0]['dfn'] == 1:
		insertedWeather = jsonSituation['weather'][1]['weather']
		insertedForecast = jsonSituation['weather'][0]['weather']

	db = Db()

	today = int(db.select("SELECT current_hour FROM current_day WHERE day_name = 'today'")[0]['current_hour']/24)
	nbPlayers = db.select("SELECT COUNT(*) FROM player")[0]['count']
	if int(insertedHour % 24) == 0:
		playerList = db.select("SELECT * FROM player;")	
		print playerList	
		for i in range(0, nbPlayers):
			print "THE PLAYER ID IS : " + str(int(playerList[i]['player_id']))
			stockList = db.select("SELECT * FROM stock WHERE stand_id="+ str(int(playerList[i]['stand_id'])) +" AND day_value="+ str(today) +";")
			totalCost = 0
			adPanelsCost = 0
			for drink in stockList:
				if drink['drink_id'] != drinkId:
					if drink['drink_id'] == 1:
						totalCost += drink['stock_quantity_before'] * 0.15
					if drink['drink_id'] == 2:
						totalCost += drink['stock_quantity_before'] * 0.3
					if drink['drink_id'] == 3:
						totalCost += drink['stock_quantity_before'] * 0.5
			playerBudget = float(playerList[i]['player_budget'])
			
			panelList = db.select("SELECT * FROM ad_panel WHERE player_id="+ str(int(playerList[i]['player_id'])) +" AND ad_panel_day="+ str(today) +";")
			for panel in panelList:
				print panel['panel_influence'][0]['panel_influence']
				adPanelsCost += panel['panel_influence'][0]['panel_influence']/10
				
			print "AD PANEL COST IS : " + str(adPanelsCost) + "PLAYER ID IS : " + str(int(playerList[i]['player_id']))
			print "DAY IS : " + str(today)
			db.execute("UPDATE player SET player_budget="+ str(playerBudget - totalCost - (adPanelsCost/10)) +"")
			print "NEW BUDGET IS : "
			print db.execute("SELECT player_budget FROM player WHERE player_id = "+ str(int(playerList[i]['player_id'])) +"")

	db.execute("""
						UPDATE current_day SET current_hour=@(insertedHour) WHERE day_name = 'today'; 
						UPDATE current_day 
						SET current_forecast=@(insertedForecast) WHERE day_name = 'today';
						UPDATE current_day 
						SET current_weather=@(insertedWeather) WHERE day_name = 'today';""", 
	{
						'insertedHour': strInsertedHour,'insertedForecast': insertedForecast, 'insertedWeather': insertedWeather
	})

	db.close()

	return json.dumps(jsonSituation), 200, {'Content-Type': 'application/json'}

#-------------------------JAVAS INFOS---------------------------
#POST SALES INFORMATIONS
@app.route('/sales', methods = ['POST'])
def postSales():
    jsonSale = request.get_json()
    name = jsonSale['player']
    item = jsonSale['item']
    quantity = jsonSale['quantity']
    
    db=Db()
    
    standId=db.execute("SELECT stand_id FROM Player WHERE Player.player_name= "+name)[0]['stand_id']
    stockId=db.execute("SELECT stock_id FROM Stock INNER JOIN Stand on Stand.stand_id=Stock.stand_id INNER JOIN Drink on Drink.drink_id=Stock.drink_id WHERE Drink.drink_name="+item)[0]['stock_id']
    stock=db.execute("SELECT * FROM Stock WHERE Stock.stock_id="+stockId)[0]
    prevSales=stock['stock_sales']
    dbQuantity=stock['stock_quantity_before']
    salestot=prevSales+quantity
    if (salestot>dbQuantity):
        salestot=dbQuantity
    db.execute("""
                    UPDATE stock SET stock_sales=@(salestot)
                    WHERE stock_id = @(stockId);""",
					{'salestot': str(salestot), 'stockId': str(stockId)})
    db.close()

    return json.dumps(jsonSale), 200, {'Content-Type': 'application/json'}

#-------------------------WEB INFOS---------------------------
@app.route('/reset', methods=['GET'])
def resetGame():
	db = Db()

	db.execute("DELETE * FROM ad_pannel;")
	db.execute("DELETE * FROM coordinate;")
	db.execute(""" 
					UPDATE current_day SET current_hour=0 WHERE day_name='today';
					UPDATE current_day SET current_weather='Not yet' WHERE day_name='today';
					UPDATE current_day SET current_forecast='Not yet' WHERE day_name='today';
	""")
	db.execute("DELETE * FROM drink;")
	db.execute("""
					INSERT INTO drink(drink_name, drink_type_hasalcool, drink_type_cold) VALUES ('limonade', false, true);
					INSERT INTO drink(drink_name, drink_type_hasalcool, drink_type_cold) VALUES ('thé', false, false);
					INSERT INTO drink(drink_name, drink_type_hasalcool, drink_type_cold) VALUES ('Cocktail', true, true);	
	""")
	db.execute("DELETE * FROM ingredient;")
	db.execute("""
				INSERT INTO ingredient(ingredient_name, ingredient_cost, hasalcohol, iscold)
				VALUES ('Water', 0, false, true);
				INSERT INTO ingredient(ingredient_name, ingredient_cost, hasalcohol, iscold)
				VALUES ('Lemon', 0.05, false, true);
				INSERT INTO ingredient(ingredient_name, ingredient_cost, hasalcohol, iscold)
				VALUES ('Tea Leaves', 0.15, false, false);
				INSERT INTO ingredient(ingredient_name, ingredient_cost, hasalcohol, iscold)
				VALUES ('Alcohol', 0.2, true, true);
				INSERT INTO ingredient(ingredient_name, ingredient_cost, hasalcohol, iscold)
				VALUES ('Fruit Mix', 0.25, false, true);
				INSERT INTO ingredient(ingredient_name, ingredient_cost, hasalcohol, iscold)
				VALUES ('Sugar', 0.02, false, false);
	""")
	db.execute("DELETE * FROM player;")
	db.execute("DELETE * FROM stand;")
	db.execute("DELETE * FROM stock;")

	db.close()

	return "Game reseted"

#THE ACTIONS A PLAYER AN DO : PRODUCE DRINKS & PLACE AD SIGNS
@app.route('/actions/<string:playername>', methods=['POST'])
def postActions(playername):
	#PlayerActionAd{"kind":"ad", "location":coordinates,"radius":float}
	#Coordinates{"latitude":float, "longitude":float}
	print "THE PLAYERNAME IS " + playername
	action = request.get_json()

	db = Db()
	nextDay = int(db.select("SELECT current_hour FROM current_day WHERE day_name = 'today'")[0]['current_hour']/24) + 1
	playerId = db.select("SELECT player_id FROM player WHERE player_name = '"+ playername +"'")[0]['player_id']
	standId = db.select("SELECT stand_id FROM player WHERE player_name = '"+ playername +"'")[0]['stand_id']
	playerBudget = db.select("SELECT player_budget FROM player WHERE player_name = '"+ playername +"'")[0]['player_budget']
	
	if action['kind'] == 'drinks':
		drinkId = db.select("SELECT drink_id FROM drink WHERE drink_name = '"+ action['prepare']['name'] +"'")[0]['drink_id']
		nbDrinks = action['prepare']['number']
		drinkPrice = action['price']['price']
		
		totalProductionCost = 0		
		if drinkId == 1:
			totalProductionCost = nbDrinks * 0.15
		if drinkId == 2:
			totalProductionCost = nbDrinks * 0.3
		if drinkId == 3:
			totalProductionCost = nbDrinks * 0.5
		
		stockList = db.select("SELECT * FROM stock WHERE stand_id="+ str(standId) +" AND day_value="+ str(nextDay) +"")
		totalCost = 0
		for drink in stockList:
			if drink['drink_id'] != drinkId:
				if drink['drink_id'] == 1:
					totalCost += drink['stock_quantity_before'] * 0.15
				if drink['drink_id'] == 2:
					totalCost += drink['stock_quantity_before'] * 0.3
				if drink['drink_id'] == 3:
					totalCost += drink['stock_quantity_before'] * 0.5

			print "THE TOTAL COST IS " + str(totalCost)

		if (playerBudget - (totalCost+totalProductionCost)) >= 0:
			print "THE DRINK ID IS " + str(drinkId)
			db.execute("DELETE FROM stock WHERE drink_id="+ str(drinkId) +" AND day_value="+ str(nextDay) +";")	
			db.execute("""
				INSERT INTO Stock(day_value,stand_id,drink_id,stock_quantity_before,stock_drink_cost)
	            VALUES (@(current_day_id),@(stand_id),@(drink_id),@(stock_quantity_before),@(stock_drink_cost));""", 
			{
				'current_day_id': nextDay,'stand_id':standId,'drink_id': drinkId,'stock_quantity_before':nbDrinks,'stock_drink_cost':drinkPrice
			})

			#db.execute("UPDATE player SET player_budget="+ str(playerBudget - totalCost) +" WHERE stand_id="+ str(standId) +";")
			actionReturn = {'sufficientFunds':"true", 'totalCost': totalProductionCost}
		else:
			actionReturn = {'sufficientFunds':"false", 'totalCost': totalProductionCost}
	
	if action['kind'] == 'ad':
		latitude = action['location']['latitude']
		longitude = action['location']['longitude']
		radius = action['radius']
		price = float(action['radius'])/10
		if (playerBudget - price) >= 0:
			db.execute("""
							INSERT INTO ad_panel(panel_influence, player_id, ad_panel_day)
							VALUES (@(radius),@(playerId), @(nextDay))
			""",{ 'radius':str(radius),'playerId': str(playerId), 'nextDay':str(nextDay) })
			actionReturn = {'sufficientFunds':"true", 'totalCost': price}
		else:
			actionReturn = {'sufficientFunds':"false", 'totalCost': price}

	print actionReturn
	return json.dumps(actionReturn), 200, {'Content-Type': 'application/json'}

#GET A PLAYER'S INFORMATIONS AND GENERAL MAP INFORMATIONS
@app.route('/map/<string:playername>', methods=['GET'])
def getInformations(playername):
	db = Db()
	informationsReturn = {'availableIngredients':[],'map':{'region':{'coordinates':{'latitude':0, 'longitude':0},'span':{'latitudeSpan':0, 'longitudeSpan':0}},'ranking':[], 'itemsByPlayer':{}}, 'playerInfo':{'cash':0,'sales':0,'profit':0,'drinksOffered':[]}}

	informationsReturn['map']['region']['coordinates']['latitude'] = db.select("SELECT latitude FROM region WHERE region_name = 1")[0]['latitude']
	informationsReturn['map']['region']['coordinates']['longitude'] = db.select("SELECT longitude FROM region WHERE region_name = 1")[0]['longitude']
	informationsReturn['map']['region']['span']['latitudeSpan'] = db.select("SELECT latitude_span FROM region WHERE region_name = 1")[0]['latitude_span']
	informationsReturn['map']['region']['span']['longitudeSpan'] = db.select("SELECT longitude_span FROM region WHERE region_name = 1")[0]['longitude_span']

	playerList = db.select("SELECT * FROM player ORDER BY player_budget DESC;")
	for checked in playerList:
		player = {'kind':'stand', 'location':{'longitude':0, 'latitude':0}, 'influence':0}
		owner = checked['player_name']
		standId = db.select("SELECT stand_id FROM player WHERE player_name = '"+ owner +"';")[0]['stand_id']
		player['location']['latitude'] = db.select("SELECT latitude FROM coordinates WHERE stand_id = "+ str(standId) +";")[0]['latitude']
		player['location']['longitude'] = db.select("SELECT longitude FROM coordinates WHERE stand_id = "+ str(standId) +";")[0]['longitude']
		player['influence'] = db.select("SELECT stand_influence FROM stand WHERE stand_id = "+ str(standId) +";")[0]['stand_influence']
		informationsReturn['map']['itemsByPlayer'][owner] = player
		informationsReturn['map']['ranking'].append(checked['player_name'])
	
	limonade = {'name':'limonade', 'price':0.15, 'hasAlcohol': False, 'isCold': True}
	the = {'name':'thé', 'price':0.3, 'hasAlcohol': False, 'isCold': False}
	Cocktail = {'name':'Cocktail', 'price':0.5, 'hasAlcohol': True, 'isCold': True}

	informationsReturn['playerInfo']['cash'] = db.select("SELECT player_budget FROM player WHERE player_name = '"+ checked['player_name'] +"';")[0]['player_budget']
	playerStand = db.select("SELECT stand_id FROM player WHERE player_name = '"+ playername +"';")[0]['stand_id']
	informationsReturn['playerInfo']['sales'] = db.select("SELECT stand_sell FROM stand WHERE stand_id="+ str(playerStand) +";")[0]['stand_sell']

	stockList = db.select("SELECT * FROM stock;")
	for stock in stockList:
		informationsReturn['playerInfo']['profit'] += stock['stock_sales'] * stock['stock_drink_cost']

	informationsReturn['playerInfo']['drinksOffered'].append(limonade)
	informationsReturn['playerInfo']['drinksOffered'].append(the)
	informationsReturn['playerInfo']['drinksOffered'].append(Cocktail)
	
	db.close()
	
	return json.dumps(informationsReturn), 200, {'Content-Type': 'application/json'}

@app.route('/map', methods =['GET'])
def getMap():
    db=Db()
    dbRegion=db.select("SELECT latitude FROM Region;")[0]
    region_center_latitude = dbRegion['latitude']
    region_center_longitude = dbRegion['longitude']
    region_center_latitude_span = dbRegion['latitude_span']
    region_center_longitude_span = dbRegion['longitude_span']
    region= {"center": {"latitude": region_center_latitude, "longitude": region_center_longitude}, "span": {"latitudeSpan": region_center_latitude_span, "longitudeSpan": region_center_longitude_span}}

    nbPlayers = db.select("SELECT COUNT(*) FROM player;")[0]["count"]
    dbRanking = db.select("SELECT * FROM player ORDER BY player_budget;")
    ranking = []
    dayValue = int(db.select("SELECT current_hour FROM Current_day;")[0]['current_hour']/24)

    itemsByPlayer = []
    playerInfo=[]
    drinksByPlayer=[]

    for i in range(0, nbPlayer):
        ranking.append({"name": dbRanking[i]["player_name"]})
        playerId=dbRanking[i]["player_id"]
        player = {}
        cash = db.select("SELECT player_budget FROM Player WHERE Player.player_id="+str(playerId)+";")[0]['player_budget']
        sales = db.select("SELECT stand_sell FROM Stand WHERE Stand.player_id="+str(playerId)+";")[0]['stand_sell']
        profits = 0 #ICI IL FAUT TROUVER LES PROFIT PAR PLAYER
        drinks = []
        nbDrinksByPlayer= 3 #Pas de creation de boisson donc seulement 3 boisson par player
        drinkAllId = db.select("SELECT drink_id FROM Drink;")
        for j in range (0, nbDrinksByPlayer):
            drink = {}
            drinkId=drinkAllId[j]['drink_id']
            dbDrink = db.select("SELECT * FROM Drink WHERE Drink.drink_id="+str(drinkId)+";")[0]
            drinkName = dbDrink["drink_name"]
            hasAlcohol = dbDrink["drink_type_hasAlcohol"]
            isCold = dbDrink["drink_type_cold"]
            price = db.select("SELECT stock_drink_cost FROM Stock WHERE Stock.drink_id ="+str(drinkId)+" AND Stock.day_value = "+dayValue+";")
            drink.append({"name": drinkName,"price": price,"hasAlcohol": hasAlcohol,"isCold": isCold})
            drinks.append({"drinksOffered": drink})
            sales = db.select("SELECT stock_sales FROM Stock  WHERE Stock.drink_id = "+str(drinkId)+" AND Stock.day_value = "+dayValue+";")
            profits = profits + sales*price   #cout de prod?
            drinksByPlayer.append({dbRanking[i]["player_name"]:drink})
        playerInfo.append({"cash" : cash, "sales" : sales, "profit" : profits, "drinksOffered" : drinks})


    nbStandByPlayer = db.select("SELECT COUNT(*) FROM Stand;")[0]["count"]
    StandByPlayer = db.select("SELECT * FROM Stand;")
    for i in range(0, nbStandByPlayer):
        mapItem=[]
        playerId=StandByPlayer[i]["player-id"]
        standId=StandByPlayer[i]["stand-id"]
        owner = db.select("SELECT player_name FROM Player WHERE Player.player_id= "+playerId+";")[0]['player_name']
        coordinate=db.select("SELECT latitude FROM Coordinates WHERE Coordinates.stand_id =  "+standId+";")[0]
        latitude=coordinate['latitude']
        longitude=coordinate['longitude']
        location={}
        location.append({"latitude": latitude,"longitude": longitude})
        influence= db.select("SELECT stand_influence FROM Stand WHERE Stand.player_id= "+playerId+";")[0]['influence']
        mapItem.append({"kind":"stand","owner": owner,"location": location,"influence": influence+";"})
        itemsByPlayer.append({"MapItem": mapItem})

    nbAdByPlayer = db.select("SELECT COUNT(*) FROM Ad_Panel;")[0]["count"]
    StandByPlayer = db.select("SELECT * FROM Ad_Panel;")
    for i in range(0, nbStandByPlayer):
        mapItem=[]
        panelId=StandByPlayer[i]["panel-id"]
        playerId=StandByPlayer[i]["player_id"]
        owner = db.select("SELECT player_name FROM Player WHERE Player.player_id= "+playerId+";")[0]['player_name']
        locationAd = db.select("SELECT latitude FROM Coordinates WHERE Coordinates.panel_id =  "+panelId+";")[0]
        latitude=locationAd['latitude']
        longitude=locationAd['longitude']
        location={}
        location.append({"latitude": latitude,"longitude": longitude})
        influence= db.select("SELECT panel_influence FROM Ad_Panel WHERE Ad_Panel.panel_id= "+panelId+";")[0]['influence']
        mapItem.append({"kind":"ad","owner": owner,"location": location,"influence": influence})
        itemsByPlayer.append({"MapItem": mapItem})

    retour = {}
    retour.append({"region" : region,"ranking":ranking,"itemsByPlayer":itemsByPlayer,"playerInfo":playerInfo,"drinksByPlayer":drinksByPlayer})
    print (retour)
    db.close()
    return json.dumps(retour), 200, {'Content-Type': 'application/json'}


#RETURNS AN ARRAY OF INGREDIENTS
@app.route('/ingredients', methods=['GET'])
def getIngredients():
	jsonIngredient = {'ingredients':[]}
	ingredientTable = []
	
	db = Db()
	ingredientsList = db.select("SELECT * FROM ingredient;")

	for checkedIngredient in ingredientsList:
		print checkedIngredient
		ingredient = {'name':checkedIngredient['ingredient_name'],'cost':checkedIngredient['ingredient_cost'],'hasAlcohol':checkedIngredient['hasalcohol'],'isCold':checkedIngredient['iscold']}
		ingredientTable.append(ingredient)

	jsonIngredient['ingredients'] = ingredientTable

	db.close()

	return json.dumps(jsonIngredient), 200, {'Content-Type': 'application/json'}

#DECORATES THE AVAILABLE DRINKS DROPDOWN BOXES [TO USE ONCE CREATING DRINKS IS AVAILABLE]
@app.route('/checkDrinks', methods=['GET']) #<string:playername> FOR LATER (SEE COMMENT BELOW)
def getAvailableDrinks():
	db = Db()
	drinksList = db.select("SELECT drink_name FROM drink") #THE DB DOESN'T TAKE IN ACCOUNT WHICH PLAYER THEY BELONG TO YET
	nbDrinks = int(db.select("SELECT COUNT(*) FROM drink;")[0]['count'])
	
	return json.dumps(drinksList), 200, {'Content-Type': 'application/json'}

#-------------------------BONUS----------------------
@app.route('/chat/post', methods=['POST'])
def postMessage():
	global chat
	message = {"text":""}
	message['text'] = request.get_json()['text']
	chat.append(message)
	return "Message sent"

#clears the chat entirely
@app.route('/chat/delete')
def deleteChat():
	global chat
	chat = ""
	return "Chat Cleared"

@app.route('/chat', methods=['GET'])
def refreshChat():
	global chat
	return json.dumps(chat), 200, {'Content-Type': 'application/json'}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
  app.run()
